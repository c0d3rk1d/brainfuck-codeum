#!/usr/bin/perl -w

use strict;
use English;

use IO::Handle;

my $WINHOST="apollo";
my $WINUSER="user";
my $WINPASS="user";

my $WINDRV="d";
my $WINDIR="\\VHDL\\bfcpu-work";

my $PRJNAME="xilinx";

sub run($)
{
	if ( system($_[0]) ) {
		print "-- ABORT ON ERROR --\n";
		sleep 1;
		exit;
	}
}

sub mkfile($$)
{
	open(O, ">$_[0]") || die $!;
	print O $_[1];
	close O;
}

if ( defined $ARGV[0] and $ARGV[0] eq 'win' )
{
	$| = 1;

	mkfile("$PRJNAME.prj", <<"EOT");
vhdl work cw6671.vhd
vhdl work fpga.vhd
EOT

	mkfile("$PRJNAME.scr", <<"EOT");
run -ifn $PRJNAME.prj -top fpga -ofn $PRJNAME.ngc
-ofmt NGC -p xc2s200-5pq208
EOT

	mkfile("$PRJNAME.imb", <<"EOT");
setMode -bs
setCable -port lpt1
addDevice -position 1 -file "$PRJNAME.bit"
Program -p 1
exit
EOT

	# Compile the VHDL sources
	#
	run "xst -ifn $PRJNAME.scr";

	# Create the design database
	#
	run "ngdbuild $PRJNAME";

	# Map the design logic gates to blocks in the physical device
	#
	run "map $PRJNAME";

	# Place and route the design
	#
	run "par $PRJNAME -w $PRJNAME";

	# Create the fpga configuration file
	#
	run "bitgen -w $PRJNAME";

	# Upload the configuration to the device
	#
	run "impact -batch $PRJNAME.imb";

	print "-- FINISHED --\n";
	sleep 1;
}
else
{
	open(N, "| netcat -T $WINHOST telnet | tee ux2win.log") || die $!;
	N->autoflush(1);

	select(undef, undef, undef, 0.25);
	print N "$WINUSER\r\n";

	select(undef, undef, undef, 0.25);
	print N "$WINPASS\r\n";

	select(undef, undef, undef, 0.25);
	print N "$WINDRV: && cd $WINDIR && xilperl ux2win.pl win && exit\r\n";
	close N;
}

