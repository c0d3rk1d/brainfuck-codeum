/*
 * The Brainf*ck CPU is Copyright (C) 2003 Clifford Wolf
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. A copy of the GNU General Public
 * License can be found at Documentation/COPYING.
 *
 * This is a Brainf*ck interpreter written in C. The implementation is
 * as close as possible to the finite-state-machine implementation used
 * in the Brainf*ck CPU itself.
 *
 * The purpose of this c program is (a) testing of brainf*ck programs
 * and the firmware and (b) documenting the implementation of the cpu
 * design in a way which easy to understand for c (no-vhdl) programmers.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MEM_SIZE 0x10000

/* the memory */
unsigned char data[MEM_SIZE] = {
	/* The first 4 bytes are start DP and SP, followed */
	/* by the BIOS image and zero-initialized memory.  */
	0x80, 0x00, 0xff, 0xff
};

/* This is the default BF-CPU BIOS. It's 124 bytes - so together with the */
/* start DP and SP we have 128 bytes rom or non-zero initialized ram.     */
unsigned char bios[] = ">++++++++[<++++++++>-]<++.++++.>+++++[<----->-]<."
">+++++[<++++>-]<++.>+++[<++++>-]<+.+++++.>>+++[<+++++[<----->-]>-]<<.,[>,]>";

FILE **files;
int filesc;

unsigned char mygetchar()
{
	int c, ch=0;

	for (c=0; files[c]==NULL && c<filesc; c++) ;

	if ( c < filesc ) {
		ch = getc(files[c]);
		if ( ch == EOF ) {
			ch = 0;
			fclose(files[c]);
			files[c] = NULL;
		}
	}

	return ch;
}

int main(int argc, char **argv)
{
	int sp; /* stack pointer       */
	int ip; /* instruction pointer */
	int dp; /* data pointer        */
	int si; /* skip index          */

	if (argc > 1) {
		files = malloc(sizeof(FILE*) * (argc-1));
		for (filesc=0; filesc+1 < argc; filesc++) {
			if ( !strcmp(argv[filesc+1], "-") )
				files[filesc] = stdin;
			else
				files[filesc] = fopen(argv[filesc+1], "r");
		}
	} else {
		files = malloc(sizeof(FILE*));
		files[0] = stdin; filesc = 1;
	}

	/* place the BIOS in the memory */
	strcpy(data+4, bios);

	/* this is done on reset-signal in the cpu. */
	dp = (data[1] << 8) | data[0];
	sp = (data[3] << 8) | data[2];
	ip = 4; si = 0;

	/* the instruction logic */
	while ( data[ip] ) {
		if ( si > 0 ) {
			switch (data[ip++]) {
				case '[':
					si++;
					break;
				case ']':
					si--;
					break;
			}
		} else {
			switch (data[ip++]) {
				case '>':
					dp++;
					break;
				case '<':
					dp--;
					break;
				case '+':
					data[dp]++;
					break;
				case '-':
					data[dp]--;
					break;
				case '.':
					putchar(data[dp]);
					fflush(stdout);
					break;
				case ',':
					data[dp] = mygetchar();
					break;
				case '[':
					if ( !data[dp] ) {
						si++;
					} else {
						data[--sp] = (ip-1) & 0xff;
						data[--sp] = (ip-1) >> 8;
					}
					break;
				case ']':
					if ( data[dp] )
						ip = ( (data[sp] << 8) |
							data[sp+1] ) + 1;
					else
						sp += 2;
					break;
			}
		}
	}

	/* the cpu will just halt and wait for reset here */
	return 0;
}

