#!/usr/bin/perl -w
#
# Copyright (c) 2003 by Clifford Wolf <www.clifford.at>
#
# The Brainf*ck CPU project
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version. A copy of the GNU General Public
# License can be found at Documentation/COPYING.
#

use strict;
use English;

my @bios = ();
my %label = ();

my ($f, $o) = (1, "");
my ($i1, $i2, $l);

open(F, $ARGV[0]) || die $!;
while (<F>) {
	chomp;
	while ( $_ ne "") {
		if (s/^\*L(.)//) {
			$bios[$#bios+1] = 0;
			$label{$1} = $#bios;
		}
		elsif (s/^\*(..)//) {
			$bios[$#bios+1] = hex $1;
		}
		elsif (s/^(.)//) {
			$bios[$#bios+1] = ord($1) if $1 =~ /([\[\]<>,\.+\-])/;
		}
	}
}
close F;

$bios[$label{"L"}] = int(($#bios+1) % 0xff) if defined $label{"L"};
$bios[$label{"H"}] = int(($#bios+1) / 0xff) if defined $label{"H"};
$bios[$#bios+1] = 0 while $#bios < 511;

for $i1 (0..15) {
	$l = "";
	for ($i2=31; $i2 >= 0; $i2--) {
		$l .= sprintf "%02x", $bios[$i1*32+$i2];
	}
	next if $l =~ /^0+$/;
	$o .= ",\n" unless $f;
	$o .= sprintf "init_%02x => x\"%s\"", $i1, $l;
	$f = 0;
}
$o .= "\n" unless $f;

open(I, "<$ARGV[1]") || die $!;
open(O, ">$ARGV[2]") || die $!;
while (<I>) {
	print O;
	if (/-- bios-begin --/) {
		print O $o;
		while (<I>) {
			last if /-- bios-end --/;
		}
		print O;
	}
}
close I;
close O;

